package lab7_inheritance.lab08;

public abstract class Number<T> {
	public abstract T add(T param);
	public abstract T multify(T param);
	public abstract T subtract(T param);
	public abstract T divide(T param);

}
