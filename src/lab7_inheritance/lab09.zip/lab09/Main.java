package lab7_inheritance.lab09;

public class Main {
    public static void main(String[] args) {
        Food food = new Fruit("wonderful", 12.4,"sprint");
        System.out.println(food);
    }
}
