package bai_tap_1.service;

public interface ITeacherService {

    void add();

    void remove();

    void display();
}
